package com.bwx.githubuser.ui.main

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import com.bwx.githubuser.R
import com.bwx.githubuser.databinding.ActivityMainBinding
import com.bwx.githubuser.model.UserModel

class MainActivity : AppCompatActivity() {
    private lateinit var mainBinding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mainBinding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(mainBinding.root)
        setupListUser()
    }

    private val listUsers: ArrayList<UserModel>
        get() {
            val name = resources.getStringArray(R.array.name)
            val username = resources.getStringArray(R.array.username)
            val avatar = resources.obtainTypedArray(R.array.avatar)
            val location = resources.getStringArray(R.array.location)
            val company = resources.getStringArray(R.array.company)
            val following = resources.getStringArray(R.array.following)
            val followers = resources.getStringArray(R.array.followers)
            val repository = resources.getStringArray(R.array.repository)

            val listUser = ArrayList<UserModel>()
            for (i in name.indices) {
                val user = UserModel(
                    name = name[i],
                    username = username[i],
                    avatar = avatar.getResourceId(i, -1),
                    location = location[i],
                    company = company[i],
                    following = following[i],
                    follower = followers[i],
                    repository = repository[i]
                )
                listUser.add(user)
            }
            return listUser
        }

    private fun setupListUser() {
        val linearLayoutManager = LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false)
        val adapter = MainAdapter(listUsers)

        mainBinding.rvUser.setHasFixedSize(true)
        mainBinding.rvUser.layoutManager = linearLayoutManager
        mainBinding.rvUser.adapter = adapter
    }
}