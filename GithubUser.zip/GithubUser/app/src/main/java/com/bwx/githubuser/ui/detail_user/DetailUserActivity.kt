package com.bwx.githubuser.ui.detail_user

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.bumptech.glide.Glide
import com.bwx.githubuser.R
import com.bwx.githubuser.databinding.ActivityDetailUserBinding
import com.bwx.githubuser.model.UserModel

class DetailUserActivity : AppCompatActivity() {

    private lateinit var detailUserBinding: ActivityDetailUserBinding

    companion object {
        const val EXTRA_USER = "extra_user"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        detailUserBinding = ActivityDetailUserBinding.inflate(layoutInflater)
        setContentView(detailUserBinding.root)

        val user = intent.getParcelableExtra<UserModel>(EXTRA_USER) as UserModel
        setUser(user)
    }

    private fun setUser(user: UserModel) {
        with(detailUserBinding) {
            tvName.text = user.name
            tvUsername.text = String.format(resources.getString(R.string.username), user.username)
            tvDescription.text = String.format(
                resources.getString(R.string.description),
                user.username,
                user.location,
                user.company
            )
            tvFollowing.text = user.following
            tvFollower.text = user.follower
            Glide.with(this@DetailUserActivity).load(user.avatar).circleCrop().into(imgUser)
        }

    }
}